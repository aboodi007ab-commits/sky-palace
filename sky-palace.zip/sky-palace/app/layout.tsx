export const metadata = {
  title: "Sky Palace",
  description: "Annual flying city — luxury, design, scarcity.",
};

import "./globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="bg-slate-950">
      <body>{children}</body>
    </html>
  );
}
