import SkyPalaceLanding from "./components/SkyPalaceLanding";

export default function Home() {
  return <SkyPalaceLanding />;
}
