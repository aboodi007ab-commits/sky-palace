\"use client\";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Menu, X, ArrowRight, ChevronRight } from "lucide-react";

// Tailwind assumed. All assets/links are placeholders and can be swapped.
// If you’re using Next.js, you can keep this as a client component.
// Countdown target: set to your next annual flight UTC time.
const COUNTDOWN_TARGET_UTC = "2026-01-01T00:00:00Z"; // TODO: replace

function useCountdown(targetIso: string) {
  const target = useMemo(() => new Date(targetIso).getTime(), [targetIso]);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const diff = Math.max(0, target - now);
  const totalSeconds = Math.floor(diff / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return { days, hours, minutes, seconds, finished: diff === 0 };
}

export default function SkyPalaceLanding() {
  const [open, setOpen] = useState(false);
  const { days, hours, minutes, seconds } = useCountdown(COUNTDOWN_TARGET_UTC);

  // Close mobile menu on hash navigation
  useEffect(() => {
    const onHash = () => setOpen(false);
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navItems = [
    { href: "#concept", label: "Concept" },
    { href: "#experience", label: "Experience" },
    { href: "#route", label: "Route" },
    { href: "#invest", label: "Invest" },
    { href: "#contact", label: "Contact" },
  ];

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const name = String(form.get("name") || "").trim();
    const email = String(form.get("email") || "").trim();
    const role = String(form.get("role") || "");
    const msg = String(form.get("message") || "");
    // TODO: replace with real endpoint
    console.log({ name, email, role, message: msg });
    alert("Request received. We will be in touch soon.");
    e.currentTarget.reset();
  };

  return (
    <div className="min-h-screen w-full scroll-smooth bg-slate-950 text-slate-100">
      {/* NAV */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/70 backdrop-blur supports-[backdrop-filter]:bg-slate-950/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4">
          <a href="#top" className="flex items-center gap-3" aria-label="Sky Palace home">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-yellow-300 to-amber-500" />
            <span className="font-semibold tracking-widest text-amber-300">SKY PALACE</span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden items-center gap-6 md:flex" aria-label="Primary">
            {navItems.map((n) => (
              <a key={n.href} href={n.href} className="text-sm text-slate-300 transition hover:text-white">
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="#contact"
              className="hidden rounded-full bg-amber-400 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-amber-300 md:inline-flex"
            >
              Join Waitlist
            </a>
            <button
              className="inline-flex rounded-xl border border-white/15 p-2 md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        <motion.nav
          initial={false}
          animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }}
          className="overflow-hidden border-t border-white/10 md:hidden"
          aria-label="Mobile"
        >
          <div className="mx-auto flex max-w-7xl flex-col px-4 py-3">
            {navItems.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="flex items-center justify-between rounded-lg px-2 py-2 text-slate-200 hover:bg-white/5"
              >
                <span>{n.label}</span>
                <ChevronRight className="h-4 w-4" />
              </a>
            ))}
            <a href="#contact" className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-amber-400 px-4 py-2 font-semibold text-slate-950">
              Join Waitlist <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </motion.nav>
      </header>

      {/* HERO */}
      <section id="top" className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="h-full w-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-200/10 via-slate-900 to-slate-950" />
        </div>
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:py-28">
          <motion.div className="flex flex-col justify-center" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
            <p className="text-sm uppercase tracking-[0.35em] text-amber-300">Once a year • 24 hours</p>
            <h1 className="mt-4 text-4xl font-semibold leading-tight md:text-6xl">
              The World’s First <span className="text-amber-300">Annual Flying City</span>
            </h1>
            <p className="mt-6 max-w-xl text-slate-300">
              A limited, invitation‑only journey above oceans, skylines, and deserts. One flight per year. A cultural event for the world; a lifetime memory for a few.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#invest" className="rounded-xl bg-amber-400 px-5 py-3 font-semibold text-slate-950 transition hover:bg-amber-300">Request Investor Deck</a>
              <a href="#contact" className="rounded-xl border border-white/20 px-5 py-3 font-semibold transition hover:border-white/40">Join the Guest Waitlist</a>
            </div>
            {/* Countdown */}
            <div className="mt-8 grid w-full max-w-md grid-cols-4 gap-2 text-center">
              {[
                { label: "Days", value: days },
                { label: "Hours", value: hours },
                { label: "Minutes", value: minutes },
                { label: "Seconds", value: seconds },
              ].map((t) => (
                <div key={t.label} className="rounded-2xl border border-white/10 p-4">
                  <div className="text-3xl font-bold tabular-nums">{String(t.value).padStart(2, "0")}</div>
                  <div className="mt-1 text-xs text-slate-400">{t.label}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div className="rounded-3xl border border-white/10 bg-slate-900/40 p-3 shadow-2xl" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}>
            <div className="aspect-[4/3] w-full overflow-hidden rounded-2xl bg-gradient-to-br from-amber-200/20 via-slate-800 to-slate-900" role="img" aria-label="Hero render placeholder" />
            <p className="mt-3 text-center text-xs text-slate-400">Hero render placeholder — drop your artwork here (optimized, lazy‑loaded).</p>
          </motion.div>
        </div>
      </section>

      {/* CONCEPT */}
      <section id="concept" className="border-t border-white/10 bg-slate-950/60">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <h2 className="text-2xl font-semibold md:text-3xl">A Cultural Event, Not Just a Flight</h2>
          <p className="mt-4 max-w-3xl text-slate-300">
            Sky Palace lifts once a year for exactly 24 hours. Thousands watch from below as a select few experience botanical domes, sky villas, and curated performances above the clouds. Scarcity makes it legendary; design makes it timeless.
          </p>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { title: "Exclusivity", desc: "One flight • limited guests • global broadcast." },
              { title: "Design", desc: "Semi‑buoyant hybrid architecture with quiet electric propulsion." },
              { title: "Comfort", desc: "Glass‑domed lounges, suites, spas, and sky gardens." },
              { title: "Sustainability", desc: "Year‑round solar & green H₂ prep; single 24‑hour mission." },
            ].map((c) => (
              <motion.div key={c.title} className="rounded-2xl border border-white/10 bg-slate-900/40 p-5" whileInView={{ opacity: 1, y: 0 }} initial={{ opacity: 0, y: 10 }} viewport={{ once: true }} transition={{ duration: 0.4 }}>
                <div className="text-lg font-semibold text-amber-300">{c.title}</div>
                <p className="mt-2 text-sm text-slate-300">{c.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* EXPERIENCE */}
      <section id="experience" className="border-t border-white/10">
        <div className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-16 md:grid-cols-2">
          <div className="space-y-4">
            <h3 className="text-2xl font-semibold md:text-3xl">The Experience</h3>
            <ul className="space-y-3 text-slate-300">
              <li>• Sunset lift‑off ceremony and sky promenade</li>
              <li>• Fine dining under the stars in glass domes</li>
              <li>• Live performances and cinematic observatories</li>
              <li>• Private sky villas & wellness rituals</li>
            </ul>
            <p className="text-slate-400">“The rarest luxury in the world: time above the clouds.”</p>
          </div>
          <motion.div className="rounded-3xl border border-white/10 bg-slate-900/40 p-3" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
            <div className="aspect-[16/10] w-full overflow-hidden rounded-2xl bg-gradient-to-br from-slate-700 to-slate-900" role="img" aria-label="Night lounge artwork placeholder" />
            <p className="mt-3 text-center text-xs text-slate-400">Night lounge artwork placeholder.</p>
          </motion.div>
        </div>
      </section>

      {/* ROUTE */}
      <section id="route" className="border-t border-white/10 bg-slate-950/60">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <div className="mb-8 flex items-end justify-between gap-4">
            <h3 className="text-2xl font-semibold md:text-3xl">24‑Hour Route</h3>
            <span className="text-xs text-slate-400">Straight‑line connectors • labels hidden for minimalism</span>
          </div>
          <div className="rounded-3xl border border-white/10 bg-slate-900/40 p-3">
            <img
              className="mx-auto h-auto w-full rounded-2xl"
              src="/assets/sky_palace_route_corrected.png"
              alt="Sky Palace Annual Route map with minimal golden lines"
              loading="lazy"
              width={1600}
              height={900}
            />
            <p className="mt-3 text-center text-xs text-slate-400">Route map placeholder — swap with your golden‑line map (no place names).</p>
          </div>
        </div>
      </section>

      {/* INVESTOR SECTION */}
      <section id="invest" className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <h3 className="text-2xl font-semibold md:text-3xl">Investor Overview</h3>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            <div className="rounded-2xl border border-white/10 bg-slate-900/40 p-5">
              <div className="text-amber-300">Revenue</div>
              <p className="mt-2 text-sm text-slate-300">Ticket tiers, sponsorships, and broadcast rights centered on a single global event.</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-slate-900/40 p-5">
              <div className="text-amber-300">Exclusivity</div>
              <p className="mt-2 text-sm text-slate-300">One flight per year amplifies demand and brand power.</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-slate-900/40 p-5">
              <div className="text-amber-300">Operations</div>
              <p className="mt-2 text-sm text-slate-300">Sea‑based dock, hybrid buoyant architecture, and modular safety.</p>
            </div>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="/files/Sky_Palace_Pitch_Deck.pptx" className="rounded-xl bg-amber-400 px-5 py-3 font-semibold text-slate-950 transition hover:bg-amber-300">Download Pitch Deck</a>
            <a href="/files/Sky_Palace_Luxury_Brochure.pdf" className="rounded-xl border border-white/20 px-5 py-3 font-semibold transition hover:border-white/40">Download Brochure</a>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="border-t border-white/10 bg-slate-950/60">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <h3 className="text-2xl font-semibold md:text-3xl">Request Access</h3>
          <p className="mt-2 max-w-2xl text-slate-300">Join the investor list or the guest waitlist. We’ll follow up with availability and details for the next annual flight.</p>
          <form onSubmit={onSubmit} className="mt-6 grid max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="sr-only" htmlFor="name">Full name</label>
            <input id="name" name="name" className="rounded-xl border border-white/10 bg-slate-900/60 px-4 py-3 outline-none placeholder:text-slate-500" placeholder="Full name" required />

            <label className="sr-only" htmlFor="email">Email</label>
            <input id="email" name="email" type="email" className="rounded-xl border border-white/10 bg-slate-900/60 px-4 py-3 outline-none placeholder:text-slate-500" placeholder="Email" required />

            <label className="sr-only" htmlFor="role">Role</label>
            <select id="role" name="role" className="rounded-xl border border-white/10 bg-slate-900/60 px-4 py-3 outline-none text-slate-300">
              <option>Investor</option>
              <option>Guest (Waitlist)</option>
              <option>Press / Media</option>
            </select>

            <button type="submit" className="rounded-xl bg-amber-400 px-4 py-3 font-semibold text-slate-950 transition hover:bg-amber-300">Request Access</button>

            <label className="sr-only" htmlFor="message">Message</label>
            <textarea id="message" name="message" className="col-span-full mt-2 rounded-xl border border-white/10 bg-slate-900/60 px-4 py-3 outline-none placeholder:text-slate-500" rows={4} placeholder="Message (optional)" />
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-8 md:flex-row">
          <p className="text-xs text-slate-400">© {new Date().getFullYear()} Sky Palace. All rights reserved.</p>
          <div className="text-xs text-slate-400">Hyderabad • Karachi • Gulf • Oman</div>
        </div>
      </footer>
    </div>
  );
}
