# Sky Palace — Next.js + Tailwind (App Router)

This template contains the SkyPalaceLanding React component pre-wired as the homepage.

## Run locally
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy (no install required on your machine)
1. **GitHub Codespaces**: Open this repo in a Codespace → run `npm install && npm run dev` → preview.
2. **StackBlitz**: Import this repo zip → it auto-installs and runs.
3. **Vercel**: Import this repo → click Deploy → it builds server-side.
